package com.hr.talentflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.hr.talentflow.model.Candidate
import com.hr.talentflow.ui.navigation.Screen
import com.hr.talentflow.ui.screens.AddCandidateScreen
import com.hr.talentflow.ui.screens.AnalyticsScreen
import com.hr.talentflow.ui.screens.DashboardScreen
import com.hr.talentflow.ui.screens.ScreeningScreen
import com.hr.talentflow.ui.theme.TalentFlowTheme
import com.hr.talentflow.viewmodel.RecruitmentViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TalentFlowTheme {
                TalentFlowApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TalentFlowApp(viewModel: RecruitmentViewModel = viewModel()) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Dashboard.route

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val candidates by viewModel.candidates.collectAsStateWithLifecycle()
    val filteredCandidates by viewModel.filteredCandidates.collectAsStateWithLifecycle()
    val dashboardKpis by viewModel.dashboardKpis.collectAsStateWithLifecycle()
    val analytics by viewModel.analytics.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()

    var selectedCandidate by remember { mutableStateOf<Candidate?>(null) }

    val activeScreen = Screen.bottomNavItems.find { it.route == currentRoute } ?: Screen.Dashboard

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(activeScreen.title) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                Screen.bottomNavItems.forEach { screen ->
                    NavigationBarItem(
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(screen.icon, contentDescription = screen.navLabel) },
                        label = { Text(screen.navLabel) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    kpis = dashboardKpis,
                    recentCandidates = candidates,
                    onViewAllClick = {
                        navController.navigate(Screen.Screening.route) {
                            launchSingleTop = true
                        }
                    },
                    onCandidateClick = { candidate ->
                        selectedCandidate = candidate
                        navController.navigate(Screen.Screening.route) {
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable(Screen.AddCandidate.route) {
                AddCandidateScreen(
                    onSubmitCandidate = { name, email, phone, role, exp, skills, status ->
                        viewModel.addCandidate(name, email, phone, role, exp, skills, status)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Candidate $name added to pipeline")
                        }
                    }
                )
            }

            composable(Screen.Screening.route) {
                ScreeningScreen(
                    candidates = filteredCandidates,
                    searchQuery = searchQuery,
                    selectedFilter = selectedFilter,
                    selectedCandidate = selectedCandidate,
                    onSearchChange = viewModel::updateSearchQuery,
                    onFilterChange = viewModel::updateFilter,
                    onCandidateSelect = { selectedCandidate = it },
                    onUpdateStatus = { id, status ->
                        viewModel.updateCandidateStatus(id, status)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Updated status to ${status.label}")
                        }
                    }
                )
            }

            composable(Screen.Analytics.route) {
                AnalyticsScreen(analytics = analytics)
            }
        }
    }
}
