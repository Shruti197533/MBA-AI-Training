package com.hr.talentflow.data

import com.hr.talentflow.model.Candidate
import com.hr.talentflow.model.CandidateStatus
import com.hr.talentflow.model.JobRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * In-memory singleton repository holding sample candidate data.
 * Designed for prototype demonstration without external backend dependencies.
 */
object CandidateRepository {

    private val initialSampleCandidates = listOf(
        Candidate(
            id = "cand-101",
            name = "Aarav Mehta",
            email = "aarav.mehta@example.com",
            phone = "+1 (415) 891-2043",
            role = JobRole.SENIOR_ANDROID,
            yearsOfExperience = 6.5,
            skills = listOf("Kotlin", "Jetpack Compose", "Coroutines", "Hilt", "Room"),
            status = CandidateStatus.INTERVIEW_SCHEDULED,
            appliedDate = "2026-11-18",
            notes = "Strong Compose architecture portfolio; technical round set for Tuesday."
        ),
        Candidate(
            id = "cand-102",
            name = "Elena Rostova",
            email = "elena.rostova@example.com",
            phone = "+1 (650) 442-9817",
            role = JobRole.PRODUCT_DESIGNER,
            yearsOfExperience = 5.0,
            skills = listOf("Material Design 3", "Figma", "Prototyping", "Design Systems"),
            status = CandidateStatus.SHORTLISTED,
            appliedDate = "2026-11-19",
            notes = "Led mobile design system migration across Android and iOS."
        ),
        Candidate(
            id = "cand-103",
            name = "Marcus Vance",
            email = "marcus.vance@example.com",
            phone = "+1 (206) 713-5590",
            role = JobRole.BACKEND_KOTLIN,
            yearsOfExperience = 4.0,
            skills = listOf("Kotlin", "Ktor", "PostgreSQL", "gRPC", "Docker"),
            status = CandidateStatus.NEW,
            appliedDate = "2026-11-21",
            notes = "Recent microservice migration experience on JVM."
        ),
        Candidate(
            id = "cand-104",
            name = "Priya Nair",
            email = "priya.nair@example.com",
            phone = "+1 (512) 309-6412",
            role = JobRole.DATA_ANALYST,
            yearsOfExperience = 3.5,
            skills = listOf("SQL", "Python", "Looker", "A/B Testing", "dbt"),
            status = CandidateStatus.INTERVIEW_SCHEDULED,
            appliedDate = "2026-11-17",
            notes = "Built hiring funnel cohort dashboards in previous fintech role."
        ),
        Candidate(
            id = "cand-105",
            name = "David Kim",
            email = "david.kim@example.com",
            phone = "+1 (312) 608-4120",
            role = JobRole.PRODUCT_MANAGER,
            yearsOfExperience = 7.0,
            skills = listOf("Roadmapping", "HR Tech", "Agile", "User Research", "SQL"),
            status = CandidateStatus.SHORTLISTED,
            appliedDate = "2026-11-20",
            notes = "Enterprise SaaS PM with prior workforce management domain depth."
        ),
        Candidate(
            id = "cand-106",
            name = "Sofia Alvarez",
            email = "sofia.alvarez@example.com",
            phone = "+1 (305) 924-1186",
            role = JobRole.QA_AUTOMATION,
            yearsOfExperience = 2.5,
            skills = listOf("Espresso", "UI Automator", "Kotlin", "CI/CD", "Appium"),
            status = CandidateStatus.NEW,
            appliedDate = "2026-11-22",
            notes = "Automated Android regression suites with GitHub Actions."
        ),
        Candidate(
            id = "cand-107",
            name = "Liam O'Connor",
            email = "liam.oconnor@example.com",
            phone = "+1 (617) 549-3304",
            role = JobRole.SENIOR_ANDROID,
            yearsOfExperience = 1.5,
            skills = listOf("Java", "XML Views", "Firebase", "REST APIs"),
            status = CandidateStatus.REJECTED,
            appliedDate = "2026-11-15",
            notes = "Experience below senior Kotlin/Compose requirement."
        ),
        Candidate(
            id = "cand-108",
            name = "Hannah Lindqvist",
            email = "hannah.l@example.com",
            phone = "+1 (404) 778-9021",
            role = JobRole.TALENT_SPECIALIST,
            yearsOfExperience = 4.5,
            skills = listOf("Technical Sourcing", "ATS Workflows", "Structured Interviewing"),
            status = CandidateStatus.SHORTLISTED,
            appliedDate = "2026-11-20",
            notes = "Specialized in mobile & platform engineering recruitment."
        )
    )

    private val _candidates = MutableStateFlow(initialSampleCandidates)
    val candidates: StateFlow<List<Candidate>> = _candidates.asStateFlow()

    val openRolesCount: Int
        get() = JobRole.entries.sumOf { it.openPositions }

    fun addCandidate(candidate: Candidate) {
        _candidates.update { currentList ->
            listOf(candidate) + currentList
        }
    }

    fun updateCandidateStatus(candidateId: String, newStatus: CandidateStatus) {
        _candidates.update { currentList ->
            currentList.map { candidate ->
                if (candidate.id == candidateId) {
                    candidate.copy(status = newStatus)
                } else {
                    candidate
                }
            }
        }
    }

    fun resetSampleData() {
        _candidates.value = initialSampleCandidates
    }
}
