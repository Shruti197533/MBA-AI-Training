package com.hr.talentflow.model

import java.util.UUID

enum class CandidateStatus(val label: String) {
    NEW("New"),
    SHORTLISTED("Shortlisted"),
    INTERVIEW_SCHEDULED("Interview Scheduled"),
    REJECTED("Rejected")
}

enum class Department(val displayName: String) {
    ENGINEERING("Engineering"),
    DESIGN("Design"),
    PRODUCT("Product"),
    DATA_ANALYTICS("Data & Analytics"),
    PEOPLE_OPS("People Ops")
}

enum class JobRole(
    val title: String,
    val department: Department,
    val openPositions: Int
) {
    SENIOR_ANDROID("Senior Android Engineer", Department.ENGINEERING, 2),
    BACKEND_KOTLIN("Backend Kotlin Developer", Department.ENGINEERING, 1),
    PRODUCT_DESIGNER("Product Designer (Mobile)", Department.DESIGN, 1),
    PRODUCT_MANAGER("Product Manager", Department.PRODUCT, 1),
    DATA_ANALYST("Data Analyst", Department.DATA_ANALYTICS, 1),
    QA_AUTOMATION("QA Automation Engineer", Department.ENGINEERING, 1),
    TALENT_SPECIALIST("Talent Acquisition Specialist", Department.PEOPLE_OPS, 1)
}

data class Candidate(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val email: String,
    val phone: String,
    val role: JobRole,
    val yearsOfExperience: Double,
    val skills: List<String>,
    val status: CandidateStatus = CandidateStatus.NEW,
    val appliedDate: String,
    val notes: String = ""
)

data class DashboardKpis(
    val totalApplicants: Int,
    val shortlisted: Int,
    val interviewsScheduled: Int,
    val openRoles: Int
)

data class DepartmentBreakdown(
    val department: Department,
    val applicantCount: Int,
    val percentage: Float
)

data class RoleBreakdown(
    val roleTitle: String,
    val count: Int
)

data class StatusBreakdown(
    val status: CandidateStatus,
    val count: Int,
    val percentage: Float
)

data class RecruitmentAnalytics(
    val averageExperienceYears: Double,
    val shortlistConversionRate: Float,
    val interviewConversionRate: Float,
    val rejectionRate: Float,
    val departmentBreakdown: List<DepartmentBreakdown>,
    val roleBreakdown: List<RoleBreakdown>,
    val statusBreakdown: List<StatusBreakdown>
)
