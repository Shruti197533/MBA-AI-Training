package com.hr.talentflow.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val navLabel: String,
    val icon: ImageVector
) {
    data object Dashboard : Screen(
        route = "dashboard",
        title = "HR Dashboard",
        navLabel = "Dashboard",
        icon = Icons.Rounded.Dashboard
    )

    data object AddCandidate : Screen(
        route = "add_candidate",
        title = "Add Candidate",
        navLabel = "Add",
        icon = Icons.Rounded.PersonAdd
    )

    data object Screening : Screen(
        route = "screening",
        title = "Candidate Screening",
        navLabel = "Screen",
        icon = Icons.Rounded.Groups
    )

    data object Analytics : Screen(
        route = "analytics",
        title = "Recruitment Analytics",
        navLabel = "Analytics",
        icon = Icons.Rounded.Analytics
    )

    companion object {
        val bottomNavItems = listOf(Dashboard, AddCandidate, Screening, Analytics)
    }
}
