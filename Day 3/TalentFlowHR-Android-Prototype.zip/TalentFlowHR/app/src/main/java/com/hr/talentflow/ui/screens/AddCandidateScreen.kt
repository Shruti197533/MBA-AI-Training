package com.hr.talentflow.ui.screens

import android.util.Patterns
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.hr.talentflow.model.CandidateStatus
import com.hr.talentflow.model.JobRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCandidateScreen(
    onSubmitCandidate: (
        name: String,
        email: String,
        phone: String,
        role: JobRole,
        experience: Double,
        skills: String,
        status: CandidateStatus
    ) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf(JobRole.SENIOR_ANDROID) }
    var experienceInput by remember { mutableStateOf("") }
    var skillsInput by remember { mutableStateOf("") }
    var selectedStatus by remember { mutableStateOf(CandidateStatus.NEW) }

    var roleDropdownExpanded by remember { mutableStateOf(false) }
    var statusDropdownExpanded by remember { mutableStateOf(false) }

    var nameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var experienceError by remember { mutableStateOf<String?>(null) }
    var skillsError by remember { mutableStateOf<String?>(null) }

    fun validateAndSubmit() {
        nameError = if (name.trim().length < 2) "Enter candidate full name" else null
        emailError = if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
            "Enter a valid email address"
        } else null
        phoneError = if (phone.filter { it.isDigit() }.length < 7) {
            "Enter a valid phone number"
        } else null
        val parsedExp = experienceInput.toDoubleOrNull()
        experienceError = if (parsedExp == null || parsedExp < 0.0 || parsedExp > 50.0) {
            "Enter valid experience (0 - 50 yrs)"
        } else null
        skillsError = if (skillsInput.trim().isEmpty()) {
            "Enter at least one skill (comma-separated)"
        } else null

        val hasError = listOf(nameError, emailError, phoneError, experienceError, skillsError)
            .any { it != null }

        if (!hasError && parsedExp != null) {
            onSubmitCandidate(
                name,
                email,
                phone,
                selectedRole,
                parsedExp,
                skillsInput,
                selectedStatus
            )
            // Reset fields after successful save
            name = ""
            email = ""
            phone = ""
            experienceInput = ""
            skillsInput = ""
            selectedRole = JobRole.SENIOR_ANDROID
            selectedStatus = CandidateStatus.NEW
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Register New Applicant",
            style = MaterialTheme.typography.titleMedium
        )
        Text(
            text = "Submitted candidates are added immediately to the screening queue, dashboard KPIs, and analytics.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF64748B)
        )

        OutlinedTextField(
            value = name,
            onValueChange = { name = it; nameError = null },
            label = { Text("Full Name *") },
            isError = nameError != null,
            supportingText = nameError?.let { msg -> { Text(msg) } },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; emailError = null },
            label = { Text("Email Address *") },
            isError = emailError != null,
            supportingText = emailError?.let { msg -> { Text(msg) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it; phoneError = null },
            label = { Text("Phone Number *") },
            isError = phoneError != null,
            supportingText = phoneError?.let { msg -> { Text(msg) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        // Applied Role Dropdown
        ExposedDropdownMenuBox(
            expanded = roleDropdownExpanded,
            onExpandedChange = { roleDropdownExpanded = !roleDropdownExpanded }
        ) {
            OutlinedTextField(
                value = selectedRole.title,
                onValueChange = {},
                readOnly = true,
                label = { Text("Applied Role") },
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = roleDropdownExpanded)
                },
                modifier = Modifier
                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = roleDropdownExpanded,
                onDismissRequest = { roleDropdownExpanded = false }
            ) {
                JobRole.entries.forEach { role ->
                    DropdownMenuItem(
                        text = { Text("${role.title} (${role.department.displayName})") },
                        onClick = {
                            selectedRole = role
                            roleDropdownExpanded = false
                        }
                    )
                }
            }
        }

        OutlinedTextField(
            value = experienceInput,
            onValueChange = { experienceInput = it; experienceError = null },
            label = { Text("Years of Experience *") },
            isError = experienceError != null,
            supportingText = experienceError?.let { msg -> { Text(msg) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = skillsInput,
            onValueChange = { skillsInput = it; skillsError = null },
            label = { Text("Key Skills (comma-separated) *") },
            placeholder = { Text("e.g. Kotlin, Jetpack Compose, SQL") },
            isError = skillsError != null,
            supportingText = skillsError?.let { msg -> { Text(msg) } },
            modifier = Modifier.fillMaxWidth()
        )

        // Initial Status Dropdown
        ExposedDropdownMenuBox(
            expanded = statusDropdownExpanded,
            onExpandedChange = { statusDropdownExpanded = !statusDropdownExpanded }
        ) {
            OutlinedTextField(
                value = selectedStatus.label,
                onValueChange = {},
                readOnly = true,
                label = { Text("Initial Status") },
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownExpanded)
                },
                modifier = Modifier
                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = statusDropdownExpanded,
                onDismissRequest = { statusDropdownExpanded = false }
            ) {
                listOf(
                    CandidateStatus.NEW,
                    CandidateStatus.SHORTLISTED,
                    CandidateStatus.INTERVIEW_SCHEDULED
                ).forEach { status ->
                    DropdownMenuItem(
                        text = { Text(status.label) },
                        onClick = {
                            selectedStatus = status
                            statusDropdownExpanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Button(
            onClick = { validateAndSubmit() },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text(
                text = "Submit Candidate",
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
