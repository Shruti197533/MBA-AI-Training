package com.hr.talentflow.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hr.talentflow.model.RecruitmentAnalytics
import com.hr.talentflow.ui.theme.BrandPrimary
import com.hr.talentflow.ui.theme.OutlineSubtle
import com.hr.talentflow.ui.theme.StatusInterviewColor
import com.hr.talentflow.ui.theme.StatusShortlistedColor
import java.util.Locale

@Composable
fun AnalyticsScreen(analytics: RecruitmentAnalytics) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Highlight Metrics: Avg Experience & Funnel Conversion
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricBox(
                    title = "Avg. Experience",
                    value = String.format(Locale.US, "%.1f yrs", analytics.averageExperienceYears),
                    accent = BrandPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricBox(
                    title = "Advance Rate",
                    value = String.format(Locale.US, "%.0f%%", analytics.shortlistConversionRate),
                    accent = StatusShortlistedColor,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Hiring Funnel Conversion Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Hiring Funnel Conversion",
                        style = MaterialTheme.typography.titleMedium
                    )
                    ProgressBreakdownRow(
                        label = "Shortlisted + Interview Stage",
                        percent = analytics.shortlistConversionRate,
                        color = StatusShortlistedColor
                    )
                    ProgressBreakdownRow(
                        label = "Interview Conversion",
                        percent = analytics.interviewConversionRate,
                        color = StatusInterviewColor
                    )
                    ProgressBreakdownRow(
                        label = "Rejection Rate",
                        percent = analytics.rejectionRate,
                        color = Color(0xFFDC2626)
                    )
                }
            }
        }

        // Applicants by Department
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Applicants by Department",
                        style = MaterialTheme.typography.titleMedium
                    )
                    analytics.departmentBreakdown.forEach { dept ->
                        ProgressBreakdownRow(
                            label = "${dept.department.displayName} (${dept.applicantCount})",
                            percent = dept.percentage,
                            color = BrandPrimary
                        )
                    }
                }
            }
        }

        // Candidate Status Breakdown
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Status Breakdown",
                        style = MaterialTheme.typography.titleMedium
                    )
                    analytics.statusBreakdown.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.status.label,
                                style = MaterialTheme.typography.bodyMedium,
                                color = statusColorFor(item.status),
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "${item.count} (${item.percentage.toInt()}%)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, OutlineSubtle),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF64748B)
            )
            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}

@Composable
private fun ProgressBreakdownRow(
    label: String,
    percent: Float,
    color: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "${percent.toInt()}%",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
        LinearProgressIndicator(
            progress = { (percent / 100f).coerceIn(0f, 1f) },
            color = color,
            trackColor = Color(0xFFE2E8F0),
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
        )
    }
}
