package com.hr.talentflow.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hr.talentflow.model.Candidate
import com.hr.talentflow.model.CandidateStatus
import com.hr.talentflow.model.DashboardKpis
import com.hr.talentflow.ui.theme.BrandPrimary
import com.hr.talentflow.ui.theme.BrandPrimaryContainer
import com.hr.talentflow.ui.theme.OutlineSubtle
import com.hr.talentflow.ui.theme.StatusInterviewColor
import com.hr.talentflow.ui.theme.StatusNewColor
import com.hr.talentflow.ui.theme.StatusRejectedColor
import com.hr.talentflow.ui.theme.StatusShortlistedColor

@Composable
fun DashboardScreen(
    kpis: DashboardKpis,
    recentCandidates: List<Candidate>,
    onViewAllClick: () -> Unit,
    onCandidateClick: (Candidate) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Prototype Mode Banner
        item {
            Surface(
                color = BrandPrimaryContainer.copy(alpha = 0.55f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BrandPrimary.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Info,
                        contentDescription = null,
                        tint = BrandPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Prototype Mode: Displaying Sample Data",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }
            }
        }

        // 2x2 KPI Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Recruitment Overview",
                    style = MaterialTheme.typography.titleMedium
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    KpiMetricCard(
                        label = "Total Applicants",
                        value = kpis.totalApplicants.toString(),
                        accent = BrandPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        label = "Shortlisted",
                        value = kpis.shortlisted.toString(),
                        accent = StatusShortlistedColor,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    KpiMetricCard(
                        label = "Interviews Scheduled",
                        value = kpis.interviewsScheduled.toString(),
                        accent = StatusInterviewColor,
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        label = "Open Roles",
                        value = kpis.openRoles.toString(),
                        accent = Color(0xFF475569),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Recent Applicants Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Applicants",
                    style = MaterialTheme.typography.titleMedium
                )
                TextButton(onClick = onViewAllClick) {
                    Text("Review All")
                }
            }
        }

        // Recent Applicants List
        items(recentCandidates.take(5), key = { it.id }) { candidate ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, OutlineSubtle),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onCandidateClick(candidate) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = candidate.name,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "${candidate.role.title} · ${candidate.yearsOfExperience} yrs",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF64748B)
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 4.dp),
                            color = OutlineSubtle.copy(alpha = 0.6f)
                        )
                        Text(
                            text = "Status: ${candidate.status.label}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = statusColorFor(candidate.status)
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = "Open candidate",
                        tint = Color(0xFF94A3B8)
                    )
                }
            }
        }
    }
}

@Composable
private fun KpiMetricCard(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, OutlineSubtle),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF64748B)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}

fun statusColorFor(status: CandidateStatus): Color = when (status) {
    CandidateStatus.NEW -> StatusNewColor
    CandidateStatus.SHORTLISTED -> StatusShortlistedColor
    CandidateStatus.INTERVIEW_SCHEDULED -> StatusInterviewColor
    CandidateStatus.REJECTED -> StatusRejectedColor
}
