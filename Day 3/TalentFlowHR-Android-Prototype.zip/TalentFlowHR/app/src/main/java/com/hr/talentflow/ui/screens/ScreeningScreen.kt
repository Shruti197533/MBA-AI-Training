package com.hr.talentflow.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hr.talentflow.model.Candidate
import com.hr.talentflow.model.CandidateStatus
import com.hr.talentflow.ui.theme.OutlineSubtle
import com.hr.talentflow.ui.theme.StatusInterviewColor
import com.hr.talentflow.ui.theme.StatusRejectedColor
import com.hr.talentflow.ui.theme.StatusShortlistedColor
import com.hr.talentflow.viewmodel.ScreeningFilter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreeningScreen(
    candidates: List<Candidate>,
    searchQuery: String,
    selectedFilter: ScreeningFilter,
    selectedCandidate: Candidate?,
    onSearchChange: (String) -> Unit,
    onFilterChange: (ScreeningFilter) -> Unit,
    onCandidateSelect: (Candidate?) -> Unit,
    onUpdateStatus: (String, CandidateStatus) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("Search name, role, or skill...") },
            leadingIcon = {
                Icon(Icons.Rounded.Search, contentDescription = null)
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        )

        // Status Filter Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ScreeningFilter.entries.forEach { filter ->
                FilterChip(
                    selected = selectedFilter == filter,
                    onClick = { onFilterChange(filter) },
                    label = { Text(filter.label) }
                )
            }
        }

        if (candidates.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "No matching candidates",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Adjust your search query or status filter to view applicants.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF64748B)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(candidates, key = { it.id }) { candidate ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, OutlineSubtle),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onCandidateSelect(candidate) }
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = candidate.name,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = candidate.status.label,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    color = statusColorFor(candidate.status)
                                )
                            }
                            Text(
                                text = "${candidate.role.title} · ${candidate.role.department.displayName}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF475569)
                            )
                            Text(
                                text = "${candidate.yearsOfExperience} yrs exp · ${candidate.skills.joinToString(", ")}",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }
        }
    }

    // Candidate Detail & Status Update Bottom Sheet
    if (selectedCandidate != null) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { onCandidateSelect(null) },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = selectedCandidate.name,
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "${selectedCandidate.role.title} · ${selectedCandidate.role.department.displayName}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF475569)
                )
                Text(
                    text = "Current Status: ${selectedCandidate.status.label}",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = statusColorFor(selectedCandidate.status)
                )

                HorizontalDivider(color = OutlineSubtle)

                DetailRow("Email", selectedCandidate.email)
                DetailRow("Phone", selectedCandidate.phone)
                DetailRow("Experience", "${selectedCandidate.yearsOfExperience} years")
                DetailRow("Applied Date", selectedCandidate.appliedDate)
                DetailRow("Skills", selectedCandidate.skills.joinToString(", "))
                if (selectedCandidate.notes.isNotEmpty()) {
                    DetailRow("Notes", selectedCandidate.notes)
                }

                HorizontalDivider(color = OutlineSubtle)

                Text(
                    text = "Update Hiring Stage",
                    style = MaterialTheme.typography.titleMedium
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onUpdateStatus(selectedCandidate.id, CandidateStatus.SHORTLISTED)
                            onCandidateSelect(null)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusShortlistedColor),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Shortlist")
                    }
                    Button(
                        onClick = {
                            onUpdateStatus(selectedCandidate.id, CandidateStatus.INTERVIEW_SCHEDULED)
                            onCandidateSelect(null)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusInterviewColor),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Interview")
                    }
                }

                OutlinedButton(
                    onClick = {
                        onUpdateStatus(selectedCandidate.id, CandidateStatus.REJECTED)
                        onCandidateSelect(null)
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejectedColor),
                    border = BorderStroke(1.dp, StatusRejectedColor.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Reject Candidate")
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF64748B),
            modifier = Modifier.weight(0.32f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(0.68f)
        )
    }
}
