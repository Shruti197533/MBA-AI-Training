package com.hr.talentflow.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val BrandPrimary = Color(0xFF1D4ED8)
val BrandOnPrimary = Color(0xFFFFFFFF)
val BrandPrimaryContainer = Color(0xFFDBEAFE)
val BrandOnPrimaryContainer = Color(0xFF1E3A8A)

val BrandSecondary = Color(0xFF0F766E)
val BrandSecondaryContainer = Color(0xFFCCFBF1)
val BrandOnSecondaryContainer = Color(0xFF115E59)

val SurfaceBackground = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceVariant = Color(0xFFF1F5F9)
val OutlineSubtle = Color(0xFFE2E8F0)

val StatusNewColor = Color(0xFF2563EB)
val StatusShortlistedColor = Color(0xFF0F766E)
val StatusInterviewColor = Color(0xFFD97706)
val StatusRejectedColor = Color(0xFFDC2626)

private val LightColorScheme = lightColorScheme(
    primary = BrandPrimary,
    onPrimary = BrandOnPrimary,
    primaryContainer = BrandPrimaryContainer,
    onPrimaryContainer = BrandOnPrimaryContainer,
    secondary = BrandSecondary,
    secondaryContainer = BrandSecondaryContainer,
    onSecondaryContainer = BrandOnSecondaryContainer,
    background = SurfaceBackground,
    surface = SurfaceCard,
    surfaceVariant = SurfaceVariant,
    outlineVariant = OutlineSubtle
)

private val AppTypography = Typography(
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun TalentFlowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = AppTypography,
        content = content
    )
}
