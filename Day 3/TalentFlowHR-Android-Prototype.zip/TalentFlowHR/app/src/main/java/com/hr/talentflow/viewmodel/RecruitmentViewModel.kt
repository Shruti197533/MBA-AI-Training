package com.hr.talentflow.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hr.talentflow.data.CandidateRepository
import com.hr.talentflow.model.Candidate
import com.hr.talentflow.model.CandidateStatus
import com.hr.talentflow.model.DashboardKpis
import com.hr.talentflow.model.Department
import com.hr.talentflow.model.DepartmentBreakdown
import com.hr.talentflow.model.JobRole
import com.hr.talentflow.model.RecruitmentAnalytics
import com.hr.talentflow.model.RoleBreakdown
import com.hr.talentflow.model.StatusBreakdown
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

enum class ScreeningFilter(val label: String) {
    ALL("All"),
    NEW("New"),
    SHORTLISTED("Shortlisted"),
    INTERVIEW("Interview"),
    REJECTED("Rejected")
}

class RecruitmentViewModel : ViewModel() {

    private val repository = CandidateRepository

    val candidates: StateFlow<List<Candidate>> = repository.candidates

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedFilter = MutableStateFlow(ScreeningFilter.ALL)
    val selectedFilter: StateFlow<ScreeningFilter> = _selectedFilter

    val filteredCandidates: StateFlow<List<Candidate>> = combine(
        candidates,
        _searchQuery,
        _selectedFilter
    ) { list, query, filter ->
        list.filter { candidate ->
            val matchesFilter = when (filter) {
                ScreeningFilter.ALL -> true
                ScreeningFilter.NEW -> candidate.status == CandidateStatus.NEW
                ScreeningFilter.SHORTLISTED -> candidate.status == CandidateStatus.SHORTLISTED
                ScreeningFilter.INTERVIEW -> candidate.status == CandidateStatus.INTERVIEW_SCHEDULED
                ScreeningFilter.REJECTED -> candidate.status == CandidateStatus.REJECTED
            }
            val q = query.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                candidate.name.lowercase().contains(q) ||
                candidate.role.title.lowercase().contains(q) ||
                candidate.skills.any { it.lowercase().contains(q) }
            matchesFilter && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboardKpis: StateFlow<DashboardKpis> = candidates.map { list ->
        DashboardKpis(
            totalApplicants = list.size,
            shortlisted = list.count { it.status == CandidateStatus.SHORTLISTED },
            interviewsScheduled = list.count { it.status == CandidateStatus.INTERVIEW_SCHEDULED },
            openRoles = repository.openRolesCount
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DashboardKpis(0, 0, 0, repository.openRolesCount)
    )

    val analytics: StateFlow<RecruitmentAnalytics> = candidates.map { list ->
        val total = list.size.coerceAtLeast(1)
        val avgExp = if (list.isEmpty()) 0.0 else list.map { it.yearsOfExperience }.average()

        val advancedCount = list.count {
            it.status == CandidateStatus.SHORTLISTED ||
                it.status == CandidateStatus.INTERVIEW_SCHEDULED
        }
        val interviewCount = list.count { it.status == CandidateStatus.INTERVIEW_SCHEDULED }
        val rejectedCount = list.count { it.status == CandidateStatus.REJECTED }

        val deptBreakdown = Department.entries.map { dept ->
            val count = list.count { it.role.department == dept }
            DepartmentBreakdown(
                department = dept,
                applicantCount = count,
                percentage = (count.toFloat() / total.toFloat()) * 100f
            )
        }.sortedByDescending { it.applicantCount }

        val roleBreakdown = JobRole.entries.map { role ->
            RoleBreakdown(
                roleTitle = role.title,
                count = list.count { it.role == role }
            )
        }.filter { it.count > 0 }.sortedByDescending { it.count }

        val statusBreakdown = CandidateStatus.entries.map { status ->
            val count = list.count { it.status == status }
            StatusBreakdown(
                status = status,
                count = count,
                percentage = (count.toFloat() / total.toFloat()) * 100f
            )
        }

        RecruitmentAnalytics(
            averageExperienceYears = avgExp,
            shortlistConversionRate = (advancedCount.toFloat() / total.toFloat()) * 100f,
            interviewConversionRate = (interviewCount.toFloat() / total.toFloat()) * 100f,
            rejectionRate = (rejectedCount.toFloat() / total.toFloat()) * 100f,
            departmentBreakdown = deptBreakdown,
            roleBreakdown = roleBreakdown,
            statusBreakdown = statusBreakdown
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        RecruitmentAnalytics(0.0, 0f, 0f, 0f, emptyList(), emptyList(), emptyList())
    )

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateFilter(filter: ScreeningFilter) {
        _selectedFilter.value = filter
    }

    fun addCandidate(
        name: String,
        email: String,
        phone: String,
        role: JobRole,
        yearsOfExperience: Double,
        skillsRaw: String,
        initialStatus: CandidateStatus
    ) {
        val parsedSkills = skillsRaw
            .split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val candidate = Candidate(
            name = name.trim(),
            email = email.trim(),
            phone = phone.trim(),
            role = role,
            yearsOfExperience = yearsOfExperience,
            skills = parsedSkills,
            status = initialStatus,
            appliedDate = LocalDate.now().toString()
        )
        repository.addCandidate(candidate)
    }

    fun updateCandidateStatus(candidateId: String, status: CandidateStatus) {
        repository.updateCandidateStatus(candidateId, status)
    }

    fun resetSampleData() {
        repository.resetSampleData()
    }
}
